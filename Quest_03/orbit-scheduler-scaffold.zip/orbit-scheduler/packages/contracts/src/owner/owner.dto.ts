/** 설계용 DTO. DB row와 분리된 소유자 화면 데이터. */
export interface TaskView {
  id: string;
  title: string;
  completed: boolean;
  dueAt: string | null;
  version: number;
}
export interface ApproveBookingInput {
  expectedVersion: number;
}
export interface ApprovalResult {
  requestId: string;
  eventId: string;
  status: 'confirmed';
  startsAt: string;
  endsAt: string;
  version: number;
}
