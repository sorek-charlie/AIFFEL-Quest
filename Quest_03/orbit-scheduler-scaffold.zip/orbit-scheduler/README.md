# ORBIT Scheduler

개인용 3D 일정 공간과 고객용 모바일 예약을 연결하는 프로젝트입니다.
**고객이 신청하고, 내가 승인해야 확정됩니다.** 프로젝트 이름은 임시 이름입니다.

## 현재 완료한 범위

실제 디렉터리·모듈별 책임 문서·API/DB 설계·작업 지침·검증 도구를 구성했습니다.
현재는 **구현 전 scaffold**입니다. 웹 화면, API 서버, DB migration, 인증·메일·캘린더 연동은 아직 구현하거나 배포하지 않았습니다.
구조 검사 통과는 예약 기능의 실행 성공을 뜻하지 않습니다.

## 먼저 볼 파일

1. [PROJECT_MAP.html](PROJECT_MAP.html) — 브라우저에서 보는 구조 지도와 파일 검색
2. [PRD.md](PRD.md) — 한 장 분량 제품 요구사항
3. [FOLDER_MAP.md](FOLDER_MAP.md) — 실제 폴더 트리와 계층별 설명
4. [docs/architecture/system.md](docs/architecture/system.md) — 전체 연결 구조
5. [docs/product/booking-lifecycle.md](docs/product/booking-lifecycle.md) — 승인·충돌·취소 규칙
6. [ROADMAP.md](ROADMAP.md) — 단계별 구현 순서와 완료 조건
7. [AGENTS.md](AGENTS.md) — AI 작업 공통 지침

## 소스 구조

| 위치 | 담당 | 분리한 이유 |
|---|---|---|
| `apps/web` | 개인 화면 + 고객 화면 | 같은 제품이지만 라우트·권한·번들을 분리 |
| `apps/api` | 요청 처리·인증·승인·저장소 연결 | 브라우저가 DB와 비밀값에 접근하지 않음 |
| `packages/domain` | 일정·시간·예약 규칙 | SQLite·Supabase·화면 기술에 독립 |
| `packages/contracts` | 공개/소유자 API 데이터 모양 | 개인 데이터의 우발적 공개 방지 |
| `packages/ui`, `packages/design-tokens` | 공용 화면 부품·디자인 값 | owner dark / guest light 일관성 |
| `database` | 두 DB의 migration·RLS·원자적 함수 | 저장소를 바꿔도 동일한 기능 계약 유지 |
| `tests` | 규칙·동시성·권한·실사용 흐름 검증 | 성공 화면뿐 아니라 실패·경쟁 상태 확인 |
| `tooling` | 역할별 에이전트 지침·MCP 계획·hook | 자동화의 책임과 권한 명시 |
| `docs`, `evidence` | 설계·운영·과제 검증 기록 | 설계와 실제 증거를 구분 |

## 이 단계에서 실행할 수 있는 것

Node.js 22 이상에서 외부 패키지 설치 없이 실행합니다.

```bash
node scripts/check-structure.mjs
node scripts/generate-map.mjs
```

`npm run check:structure`, `npm run map`도 같은 작업입니다.
아직 `npm run dev`는 없습니다. 불필요한 설치를 피하려고 앱 의존성·잠금 파일은 첫 구현 단계에서 호환 버전을 확인한 뒤 추가하도록 했습니다.

## 저장·공개 원칙

로컬: SQLite → 클라우드: Supabase PostgreSQL. 한 실행 환경은 하나의 저장소만 사용합니다.
고객은 빈 시간과 자신의 요청 상태만 봅니다. 예약 확정은 서버의 원자적 승인 처리 결과로만 표시합니다.
`.env`, 실제 DB, 백업, 토큰, 실제 고객 정보는 소스에 넣지 않습니다.

문서 작성일: 2026-10-29. 외부 자료와 확인 범위는 [references.md](docs/sources/references.md)에 기록했습니다.
