# RLS 정책 검증 사양

경로: `database/supabase/policies`

**책임**: 테이블별 SELECT·INSERT·UPDATE·DELETE 소유권.

**연결 규칙**: 실행 원본은 migrations, 여기에는 설명·검증 SQL.

**금지**: 정책 파일과 migration에 서로 다른 실행 원본 유지.

**구현 시 배치할 파일**: ownership-verification.sql (구현 단계). 이름은 예정안이며 README 외 소스의 존재를 의미하지 않습니다.

**완료 판단**: 이 모듈의 요구사항과 대응하는 `docs/quality/test-matrix.md`의 시나리오를 충족하고, 실제 실행 결과를 기록합니다.

현재 단계: 설계·폴더 구성. 기능 구현과 실행 검증은 아직 진행하지 않았습니다.
