# 로컬 스키마 변경 이력

경로: `database/sqlite/migrations`

**책임**: 번호순 SQL, FK·CHECK·UNIQUE·인덱스.

**연결 규칙**: 적용된 파일 수정 대신 새 migration 추가.

**금지**: Supabase SQL을 SQLite에 그대로 사용.

**구현 시 배치할 파일**: 0001_initial.sql (구현 단계). 이름은 예정안이며 README 외 소스의 존재를 의미하지 않습니다.

**완료 판단**: 이 모듈의 요구사항과 대응하는 `docs/quality/test-matrix.md`의 시나리오를 충족하고, 실제 실행 결과를 기록합니다.

현재 단계: 설계·폴더 구성. 기능 구현과 실행 검증은 아직 진행하지 않았습니다.
