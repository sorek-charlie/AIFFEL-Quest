# 할 일 CRUD

경로: `apps/web/src/features/tasks`

**책임**: 할 일 추가·조회·수정·완료·삭제와 필터.

**연결 규칙**: platform/api를 통해 API 호출. 완료 여부와 일정 점유는 별개.

**금지**: 브라우저 메모리를 최종 저장소로 사용.

**구현 시 배치할 파일**: TaskList.tsx, TaskForm.tsx, useTasks.ts. 이름은 예정안이며 README 외 소스의 존재를 의미하지 않습니다.

**완료 판단**: 이 모듈의 요구사항과 대응하는 `docs/quality/test-matrix.md`의 시나리오를 충족하고, 실제 실행 결과를 기록합니다.

현재 단계: 설계·폴더 구성. 기능 구현과 실행 검증은 아직 진행하지 않았습니다.
