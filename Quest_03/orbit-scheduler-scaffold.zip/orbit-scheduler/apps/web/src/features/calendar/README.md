# 2D 일정과 상세 편집

경로: `apps/web/src/features/calendar`

**책임**: 같은 일정 데이터를 2D·3D 뷰모델로 제공.

**연결 규칙**: 명시적 저장 결과로 화면 갱신. 서버 충돌 응답 표시.

**금지**: 화면 드래그만으로 서버 저장 성공 판정.

**구현 시 배치할 파일**: Calendar2D.tsx, EventEditor.tsx, calendarViewModel.ts. 이름은 예정안이며 README 외 소스의 존재를 의미하지 않습니다.

**완료 판단**: 이 모듈의 요구사항과 대응하는 `docs/quality/test-matrix.md`의 시나리오를 충족하고, 실제 실행 결과를 기록합니다.

현재 단계: 설계·폴더 구성. 기능 구현과 실행 검증은 아직 진행하지 않았습니다.
