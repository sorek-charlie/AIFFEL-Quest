# 로그인·인증 복귀 경로

경로: `apps/web/src/app/auth`

**책임**: 소유자 로그인·로그아웃·세션 만료 안내.

**연결 규칙**: platform/session과 백엔드 인증 엔드포인트 사용.

**금지**: DB 테이블 직접 조회.

**구현 시 배치할 파일**: AuthRoutes.tsx, SessionExpired.tsx. 이름은 예정안이며 README 외 소스의 존재를 의미하지 않습니다.

**완료 판단**: 이 모듈의 요구사항과 대응하는 `docs/quality/test-matrix.md`의 시나리오를 충족하고, 실제 실행 결과를 기록합니다.

현재 단계: 설계·폴더 구성. 기능 구현과 실행 검증은 아직 진행하지 않았습니다.
