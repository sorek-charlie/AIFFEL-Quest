# 웹 앱

라우트 진입은 src/app, 기능은 src/features, 3D 표현은 src/scene, API·세션·캐시는 src/platform에 둡니다.
공개·개인 화면은 별도 bundle boundary를 사용하고 3D는 개인 라우트 진입 후만 로드합니다.

현재 README와 설계만 있습니다. React 화면·router·Vite 설정은 구현 단계에서 추가합니다.
첫 구현 순서: Todo DOM 화면 → 2D 일정 → 고객 예약 → 개인 3D.

사용 패키지 방향: React·TypeScript·Vite·R3F. 실제 버전·의존성·lockfile은 호환성 확인 후 작성합니다.
