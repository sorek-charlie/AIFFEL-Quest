# API 앱

transport/http는 요청을 해석하고 application에 전달합니다. application은 domain/ports로 저장을 요청하며 bootstrap이 구체 어댑터를 주입합니다.
platform에는 환경·로그·보안처럼 기능 공통 사항만 둡니다. 예약 규칙을 generic utils로 흩뜨리지 않습니다.

현재 API 서버·DB 연결은 미구현입니다. root의 구조 검사만 실행 가능합니다.
첫 구현은 Todo CRUD이며 예약 승인·공개 신청은 원자성·권한 검증 이후 활성화합니다.
